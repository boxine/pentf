const assert = require('assert');

async function run() {
    assert(1 + 1 == 2);
}

module.exports = {
    description: 'My first test',
    resources: [],
    run,
};
